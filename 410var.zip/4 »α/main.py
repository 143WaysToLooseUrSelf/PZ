from math import factorial

def sigma(first, last, n):

    if n <= 0:
        raise ValueError("Значение n должно быть больше 0")
    if type(n) != int:
        raise TypeError("n должно быть целым числом")

    total = 0
    for k in range(first, last + 1):
        if k != 7:
            total += ((-1) ** k) * (k - 7) / factorial(k + n)
        else: print('Вышли за условие')
    return total

if __name__ == "__main__":
    try:
        n = int(input("Введите значение n: "))
        result = sigma(1, n, n)
        print(f"Сумма Q равна: {round(result, 3)}")
    except (ValueError, TypeError) as e:
        print(f"Ошибка: {e}")
