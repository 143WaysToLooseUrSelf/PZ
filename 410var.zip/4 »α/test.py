import unittest
from main import sigma

class TestSigma(unittest.TestCase):
    def test_correct_values(self):
        # Проверка правильности расчета
        self.assertAlmostEqual(sigma(1, 1, 1), 3.0, places=3)
        self.assertAlmostEqual(sigma(1, 2, 2), 0.792, places=3)
        self.assertAlmostEqual(sigma(1, 3, 3), 0.214, places=3)

    def test_negative_n(self):
        # Проверка исключения ValueError при недопустимом n
        with self.assertRaises(ValueError):
            sigma(1, 5, -3)

    def test_non_integer_n(self):
        # Проверка исключения TypeError при некорректном типе n
        with self.assertRaises(TypeError):
            sigma(1, 5, 3.5)
        with self.assertRaises(TypeError):
            sigma(1, 5, "five")

if __name__ == "__main__":
    unittest.main()

