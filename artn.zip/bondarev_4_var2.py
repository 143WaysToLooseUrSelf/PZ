import unittest

def solve(k, x):
    U = 1
    for t in range(2, k + 1):
        sum = 0
        for i in range(1, t + 1):
            if i!= 6 or i!=4:
                sum += (i - 4) / (i - 6)
        if t != 12:
            p = (t * (x ** t)) / (t - 12)

        U *= p * sum

    return U

# k = int(input("k: "))
# x = int(input("x: "))
# result = solve(k, x)
# print("Value of U:", result)


class TestC(unittest.TestCase):
    def test_p(self):
        self.assertEqual(solve(3, 2), 3.3635555555555556)
        self.assertEqual(solve(3, 4), 107.63377777777778)
        self.assertEqual(solve(5, 2), 382.01448747795416)

if __name__ == "__main__":
    unittest.main()