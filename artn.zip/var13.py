import math
import unittest
n = int(input("введите количество слагаемых "))
def scary_formula(n):
    q = 0
    for k in range(1,n+1):
        if k!=3 and k!=7:
         q+=((k-3)**(k-5)*(k+7))/math.factorial(k)
    return q
print(scary_formula(n))
class TestFormula(unittest.TestCase):
    def test_formula(self):
        self.assertEqual(scary_formula(1), 0.5)
        self.assertEqual(scary_formula(2),-4)
        self.assertEqual(scary_formula(3),-4)

if __name__ == "__main__":
    unittest.main(TestFormula().test_formula())